/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dominykas
 */
public class ReviewData {
    /*
    type ReviewData struct {
	ID           string `json:"ID"`
	UserDataID   string `json:"UserDataID"`
	CTIDataID    string `json:"CTIDataID"`
	Accuracy     int    `json:"Completeness"`
	Timeliness   int    `json:"Actionability"`
	Completeness int    `json:"Relevance"`
	Consistency  int    `json:"Accuracy "`
	ReviewText   string `json:"ReviewText"`
}
    */
    public String ID;
    public String UserDataID;
    public String CTIDataID;
    public int Accuracy;
    public int Timeliness;
    public int Completeness;
    public int Consistency;
    public String ReviewText;

    public int getScore() {
        int score = (Accuracy + Timeliness + Completeness + Consistency) / 4;
        return score;
    }
    
    
}
