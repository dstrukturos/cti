/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dominykas
 */
public class UserData {
    /*
    type UserData struct {
	ID          string `json:"ID"`
	UploadCount int    `json:"UploadCount"`
	Points      int    `json:"Points"`
	Subscribed  int    `json:"Subscribed"`
	Balance     int    `json:"Balance"`
    }
    */
    
    public String ID;
    public int UserLevel; // 0, 1, 2, 3 - four levels
    public int UploadCount;
    public int Points;
    public int Subscribed;
    public int Balance;
    
}
