/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dominykas
 */
public class CTIData {

    /*
    type CTIData struct {
	ID         string `json:"ID"`
	Name       string `json:"Name"`
	Uploader   string `json:"Uploader"`
	Timestamp  int    `json:"Timestamp"`
	CID        string `json:"CID"`
	EncryptKey string `json:"encryptKey"`
	Points     int    `json:"Points"`
    }
    */
    
    
    public String ID;
    public String Name;
    public String Uploader;
    public int Timestamp;
    public String CID;
    public String EncryptKey;
    public int Points;
    public int Level;
    
    
}
