/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dominykas
 */

/*

Rw1: producer reward score;
Rw2: consumer reward score;
Rw3: reviewer reward score;
Ps: penalty score;
PID: producer ID;
CID: consumer ID;
Prw: PID producer reward score; // Rating points for one year 
Crw: CID consumer reward score; // Rating points for one year 
Prs: PID producer rating score; // Rating points for five years 
Crs: CID consumer rating score; // Rating points for five years 
Result: Reward scores and rating scores calculated for PID and CID

If PID provided CTI data
    Prw = Prw + Rw1;
    Prs = Prs + Rw1;
If CID have requested the CTI data provided
    Crw = Crw + Rw2;
    Crs = Crs + Rw2;
If CID reviewed CTI data
    Crw = Crw + Rw3;
    Crs = Crs + Rw3;
    Prw = Prw + Ps * rating;
    Prs = Prs + Ps * rating;
    If PID reviewed CID review
        If review is valid
            Crw = Crw + Rw3;
            Crs = Crs + Rw3;
        If PID adds the review to CTI data
            Prw = Prw + Rw3;
            Prs = Prs + Rw3;

*/

public class RewardCalculator {
    public static int getPoints(String action, UserData userData, CTIData ctiData, ReviewData reviewData) {
        int points = 0;
        switch (action) {
            case "addCTI":
                points = ctiData.Points;
                break;
            case "viewCTI":
                points = 1;
                break;
            case "addReview":
                // int n = getNumberOfReviews(ctiData);
                // if (n >= 3) points = getAverageReviewScore(ctiData);
                points = reviewData.getScore();
                break;
            case "getReview":
                int rating = reviewData.getScore();
                points = 1 * rating;
                break;
        }
        return points;
    }
}
