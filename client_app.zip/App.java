import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import io.grpc.Grpc;
import io.grpc.ManagedChannel;
import io.grpc.TlsChannelCredentials;
import org.hyperledger.fabric.client.CommitException;
import org.hyperledger.fabric.client.CommitStatusException;
import org.hyperledger.fabric.client.Contract;
import org.hyperledger.fabric.client.EndorseException;
import org.hyperledger.fabric.client.Gateway;
import org.hyperledger.fabric.client.GatewayException;
import org.hyperledger.fabric.client.SubmitException;
import org.hyperledger.fabric.client.identity.Identities;
import org.hyperledger.fabric.client.identity.Identity;
import org.hyperledger.fabric.client.identity.Signer;
import org.hyperledger.fabric.client.identity.Signers;
import org.hyperledger.fabric.client.identity.X509Identity;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.cert.CertificateException;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import javax.swing.*;  

public final class App {
	private static final String MSP_ID = System.getenv().getOrDefault("MSP_ID", "Org1MSP");
	private static final String CHANNEL_NAME = System.getenv().getOrDefault("CHANNEL_NAME", "mychannel");
	private static final String CHAINCODE_NAME = System.getenv().getOrDefault("CHAINCODE_NAME", "basic");

	// Path to crypto materials.
	private static final Path CRYPTO_PATH = Paths.get("../../test-network/organizations/peerOrganizations/org1.example.com");
	// Path to user certificate.
	private static final Path CERT_PATH = CRYPTO_PATH.resolve(Paths.get("users/User1@org1.example.com/msp/signcerts/cert.pem"));
	// Path to user private key directory.
	private static final Path KEY_DIR_PATH = CRYPTO_PATH.resolve(Paths.get("users/User1@org1.example.com/msp/keystore"));
	// Path to peer tls certificate.
	private static final Path TLS_CERT_PATH = CRYPTO_PATH.resolve(Paths.get("peers/peer0.org1.example.com/tls/ca.crt"));

	// Gateway peer end point.
	private static final String PEER_ENDPOINT = "localhost:7051";
	private static final String OVERRIDE_AUTH = "peer0.org1.example.com";

	private Contract contract;
	private final String assetId = "asset" + Instant.now().toEpochMilli();
	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

        public String executeChainCode(String operation, Object obj) throws Exception {
                String jsonResult = "";
		// The gRPC client connection should be shared by all Gateway connections to
		// this endpoint.
		var channel = newGrpcConnection();

		var builder = Gateway.newInstance().identity(newIdentity()).signer(newSigner()).connection(channel)
				// Default timeouts for different gRPC calls
				.evaluateOptions(options -> options.withDeadlineAfter(5, TimeUnit.SECONDS))
				.endorseOptions(options -> options.withDeadlineAfter(15, TimeUnit.SECONDS))
				.submitOptions(options -> options.withDeadlineAfter(5, TimeUnit.SECONDS))
				.commitStatusOptions(options -> options.withDeadlineAfter(1, TimeUnit.MINUTES));

		
                byte[] response = "".getBytes();
		try (var gateway = builder.connect()) {
			// Get a network instance representing the channel where the smart contract is
			// deployed.
			var network = gateway.getNetwork(CHANNEL_NAME);

			// Get the smart contract from the network.
			contract = network.getContract(CHAINCODE_NAME);
			
                        switch (operation) {
                            case "AddCTI":
                                CTIData ctiData = (CTIData)obj;
                                response = contract.submitTransaction("AddCTIItem", ctiData.Name, String.valueOf(ctiData.Timestamp), ctiData.CID, ctiData.EncryptKey, String.valueOf(ctiData.Points), String.valueOf(ctiData.Level));
                                break;
                            case "UpdateCTIItem":
                                //UpdateCTIItem(ctx contractapi.TransactionContextInterface, id string, name string, timestamp int, cid string, encryptKey string, points, level int)
                                CTIData ctiDataUpdate = (CTIData)obj;
                                response = contract.submitTransaction("UpdateCTIItem", ctiDataUpdate.ID, ctiDataUpdate.Name, String.valueOf(ctiDataUpdate.Timestamp), ctiDataUpdate.CID, ctiDataUpdate.EncryptKey, String.valueOf(ctiDataUpdate.Points), String.valueOf(ctiDataUpdate.Level));
                                break;
                            case "GetAllCTIItems":
                                response = contract.evaluateTransaction("GetAllCTIItems");
                                break;
                            case "GetCTIItemsFilteredBySubscriptionLevel":
                                response = contract.evaluateTransaction("GetCTIItemsFilteredBySubscriptionLevel");
                                break;
                            case "DeleteCTIItemByID":
                                //DeleteCTIItemByID(ctx contractapi.TransactionContextInterface, id string)
                                CTIData ctiDataDelete = (CTIData)obj;
                                response = contract.submitTransaction("DeleteCTIItemByID", ctiDataDelete.ID);
                                break;
                                
                            case "AddUserData":
                                UserData userData = (UserData)obj;
                                // AddUserData(ctx contractapi.TransactionContextInterface, uploadCount int, points int, subscribed int, balance int) 
                                response = contract.submitTransaction("AddUserData", String.valueOf(userData.UploadCount), String.valueOf(userData.Points), String.valueOf(userData.Subscribed), String.valueOf(userData.Balance));
                                break;
                            case "GetUserData":
                                response = contract.evaluateTransaction("GetUserData");
                                break;
                            case "UpdateUserData":
                                UserData userDataUpdate = (UserData)obj;
                                // UpdateUserData(ctx contractapi.TransactionContextInterface, uploadCount, points, subscribed, balance int)
                                response = contract.submitTransaction("UpdateUserData", String.valueOf(userDataUpdate.UploadCount), String.valueOf(userDataUpdate.Points), String.valueOf(userDataUpdate.Subscribed), String.valueOf(userDataUpdate.Balance));
                                break;
                            case "AddReviewData":
                                // AddReviewData(ctx contractapi.TransactionContextInterface, ctiDataID string, accuracy, timeliness, completeness, consistency int, reviewText string)
                                ReviewData reviewData2 = (ReviewData)obj;
                                response = contract.submitTransaction("AddReviewData", reviewData2.CTIDataID, String.valueOf(reviewData2.Accuracy), String.valueOf(reviewData2.Timeliness), String.valueOf(reviewData2.Completeness), String.valueOf(reviewData2.Consistency), reviewData2.ReviewText);
                                break; 
                            case "GetReviewDataByCTIDataID":
                                //response = contract.evaluateTransaction("GetReviewDataByCTIDataID", ((CTIData)obj).ID);
                                // GetReviewsByCTIDataID(ctx contractapi.TransactionContextInterface, ctiDataID string)
                                response = contract.evaluateTransaction("GetReviewDataByCTIDataID", ((CTIData)obj).ID);
                                break;
                            case "GetAllReviewData":
                                response = contract.evaluateTransaction("GetAllReviewData");
                                break;
                         }
		} finally {
			channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
    		}
                jsonResult = new String(response);
                return jsonResult;
	}
        
        
       
	private static ManagedChannel newGrpcConnection() throws IOException {
		var credentials = TlsChannelCredentials.newBuilder()
				.trustManager(TLS_CERT_PATH.toFile())
				.build();
		return Grpc.newChannelBuilder(PEER_ENDPOINT, credentials)
				.overrideAuthority(OVERRIDE_AUTH)
				.build();
	}

	private static Identity newIdentity() throws IOException, CertificateException {
		var certReader = Files.newBufferedReader(CERT_PATH);
		var certificate = Identities.readX509Certificate(certReader);

		return new X509Identity(MSP_ID, certificate);
	}

	private static Signer newSigner() throws IOException, InvalidKeyException {
		var keyReader = Files.newBufferedReader(getPrivateKeyPath());
		var privateKey = Identities.readPrivateKey(keyReader);

		return Signers.newPrivateKeySigner(privateKey);
	}

	private static Path getPrivateKeyPath() throws IOException {
		try (var keyFiles = Files.list(KEY_DIR_PATH)) {
			return keyFiles.findFirst().orElseThrow();
		}
	}

	public App() {

	}


	

	
	
}
